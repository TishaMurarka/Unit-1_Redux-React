import {BUY_ICECREAM} from "./iceCreamTypes";

export const buyicecream =() =>{
    return{
        type: BUY_ICECREAM,
    }
}